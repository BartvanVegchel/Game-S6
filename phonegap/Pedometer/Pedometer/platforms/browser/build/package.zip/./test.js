
var isDone = false;
var parseFormat = d3.time.format("%Y-%m-%d");
var format = d3.time.format("%B %d, %Y");
var counter = 0;
var maxDate = new Date(2013, 0, 1);
var onOpened = function() {
    // $("#vis").prepend("<div>Started</div>");
};
var onMessage = function(message) {
    if (message.data == "processing" && !isDone) {
        $("#status-message").html("Almost done! Sit tight just a little bit longer...");
        $(".week").addClass("done");
    } else {
        var msg = message.data.split(";");
        var counter = parseInt(msg[0]);
        var date = parseFormat.parse(msg[1]);
        if (date > maxDate) {
            maxDate = date;
            $("#latest-date").html("Collecting the week of " + format(date));
            $(".week:lt(" + (counter) + ")").addClass("done");
        }
    }
};
var onError = function(e) {
    $("#vis").append("<span class=\"error\">error</span>");
};
var onClose = function() {
    $("#vis").find(".week").addClass("done");
};

var uhash = "9ebecf37d9c7db59b8ce0ea9fac589ad";
var data_refresh_token = "249d72b07ca57383";

$(document).ready(function() {
    var channel = new goog.appengine.Channel('AHRlWrpwnpSe9_TlQf8dm2m-JqtzxEsUyJP14XxmJ2953k1lVre-j5VxnbNBJqfXW3e0DAvkULXjMCcDrGa6VGfNHu_LYiJcecuz-eZbCtf2IphpkCHJfc0');
    var socket = channel.open();
    socket.onopen = onOpened;
    socket.onmessage = onMessage;
    socket.onerror = onError;
    socket.onclose = onClose;

    var fetchLink = "/fetch_data/" + uhash + "/" + data_refresh_token;
    var count = 0;
    var fail = function(data) {
        var message = "We weren't able to get your data. Feel free to <a href=\"" + fetchLink + "\">try again</a>! If this keeps happening, please <a href=\"mailto:hello@moveoscope.com?Subject=Move-O-Scope%20Error&Body=My%20link%3A%20https%3A//app.moveoscope.com" + fetchLink + "\">contact us</a>.";

        if (data.error && data.error == "invalid_grant") {
            message = "It looks like you revoked access to Move-O-Scope. In order to get your latest data simply follow the steps outlined on the <a href=\"/\">Move-O-Scope homepage</a>.";
        } else {
            console.error("Unknown error", data);
        }

        $(".week").remove();
        $(".loading-anim").addClass("ready");
        $("#loading-anim").css({"display": "none"});
        $("#status-message").html(message);
    }
    var startDataGathering = function(data) {
        if (!_.isObject(data)) {
            try {
                data = JSON.parse(data);
            } catch (e) {
                console.error("could not parse reponse from server");
            }
        }
        if (count < 10 && data.status && data.status == "in progress") {
            $.post("/data/" + uhash, startDataGathering).fail(fail);
            var socket = channel.open();
            counter = 0;
            count++;
        } else if (count == 10) {
            console.error("Too many attempts")
        } else if (data.status == "rate_over_limit") {
            $("#status-message").html("We've made too many requests to the Moves API. <a href=\"" + fetchLink + "\">Try again later</a>!");
        } else if (data.status == "done") {
            isDone = true;
            $(".loading-anim").addClass("ready");
            $("#loading-anim").css({"display": "none"});
            $("#status-message").html("We're done! Let's fire up the Move-O-Scope!");
            $(".week").addClass("done");
            $("#show-vis").show();
        } else {
            fail(data);
        }
    };

    $.post("/data/" + uhash, startDataGathering).fail(fail);
})
